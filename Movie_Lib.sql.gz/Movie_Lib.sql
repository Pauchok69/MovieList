-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 06 2017 г., 18:30
-- Версия сервера: 5.7.17-0ubuntu0.16.04.1
-- Версия PHP: 7.1.2-3+deb.sury.org~xenial+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Movie_Lib`
--

-- --------------------------------------------------------

--
-- Структура таблицы `film`
--

CREATE TABLE `film` (
  `id` int(11) NOT NULL,
  `title` tinytext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `release_year` year(4) NOT NULL,
  `format` tinytext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `stars` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `film`
--

INSERT INTO `film` (`id`, `title`, `release_year`, `format`, `stars`) VALUES
(8, 'Blazing Saddles', 1974, 'VHS', 'Mel Brooks, Clevon Little, Harvey Korman, Gene Wilder, Slim Pickens, Madeline Kahn'),
(9, 'Casablanca', 1942, 'DVD', 'Humphrey Bogart, Ingrid Bergman, Claude Rains, Peter Lorre'),
(10, 'Charade', 1953, 'DVD', 'Audrey Hepburn, Cary Grant, Walter Matthau, James Coburn, George Kennedy'),
(11, 'Cool Hand Luke', 1967, 'VHS', 'Paul Newman, George Kennedy, Strother Martin'),
(12, 'Butch Cassidy and the Sundance Kid', 1969, 'VHS', 'Paul Newman, Robert Redford, Katherine Ross'),
(13, 'The Sting', 1973, 'DVD', 'Robert Redford, Paul Newman, Robert Shaw, Charles Durning'),
(14, 'The Muppet Movie', 1979, 'DVD', 'Jim Henson, Frank Oz, Dave Geolz, Mel Brooks, James Coburn, Charles Durning, Austin Pendleton\r\n');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `film`
--
ALTER TABLE `film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
